# -*- coding: utf-8 -*-
"""PDF de representación visual del CFDI (no es el CFDI fiscal: es para leerlo
cómodo, imprimir o compartir).

Personalizable con pdf_config.json (en la carpeta de datos):
  - título / subtítulo / pie de página
  - logo (PNG o JPG)
  - color principal
  - ajustes por RFC (cada cliente con su nombre y su logo)

Cada PDF lleva una LETRA GRANDE según qué es para quien lo lee:
  I ingreso · G gasto · N nómina · P pago · E nota de crédito · T traslado
"""
import copy
import json
import re
from pathlib import Path
from typing import Callable, Dict, List, Optional

from .lector import CLASES

# ---------------------------------------------------------------- configuración
CONFIG_DEFAULT = {
    "_ayuda": [
        "Configuración del PDF de DESCARGA XML EDDP.",
        "general: aplica a todos. por_rfc: sobreescribe para un RFC (tu cliente).",
        "titulo vacío = se usa el nombre del contribuyente que viene en el XML.",
        "logo: ruta a un PNG/JPG (ej. C:/Users/Erick/logos/eddp.png). Vacío = sin logo.",
        "color_primario: color hexadecimal, ej. #1F4E78.",
        "nombre_archivo admite: {fecha} {clase} {tipo} {rfc_contraparte} {serie} {folio} {uuid8} {uuid}",
    ],
    "general": {
        "titulo": "",
        "subtitulo": "Representación impresa de CFDI",
        "logo": "",
        "color_primario": "#1F4E78",
        "pie": "Generado con DESCARGA XML EDDP",
        "mostrar_letra_clase": True,
        "mostrar_inteligencia": True,
        "mostrar_sello_sat": False,
        "nombre_archivo": "{fecha}_{clase}_{rfc_contraparte}_{serie}{folio}_{uuid8}",
    },
    "por_rfc": {
        "XAXX010101000": {"titulo": "EJEMPLO: NOMBRE DE TU CLIENTE", "logo": ""}
    },
}


def ruta_config_pdf() -> Path:
    from .config import carpeta_datos
    return carpeta_datos() / "pdf_config.json"


def cargar_config_pdf(ruta: Optional[str] = None) -> Dict:
    """Lee pdf_config.json (lo crea con valores de ejemplo si no existe).
    Campos faltantes se completan con los defaults: un JSON a medias no truena."""
    p = Path(ruta) if ruta else ruta_config_pdf()
    cfg = copy.deepcopy(CONFIG_DEFAULT)
    if not p.exists():
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(CONFIG_DEFAULT, indent=2, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass
        return cfg
    try:
        leido = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return cfg                                    # JSON roto: defaults, sin tronar
    cfg["general"].update({k: v for k, v in (leido.get("general") or {}).items()})
    cfg["por_rfc"] = {str(k).upper(): v for k, v in (leido.get("por_rfc") or {}).items()
                      if isinstance(v, dict)}
    return cfg


def guardar_config_pdf(cfg: Dict, ruta: Optional[str] = None) -> str:
    p = Path(ruta) if ruta else ruta_config_pdf()
    p.parent.mkdir(parents=True, exist_ok=True)
    salida = {"_ayuda": CONFIG_DEFAULT["_ayuda"], "general": cfg.get("general", {}),
              "por_rfc": cfg.get("por_rfc", {})}
    p.write_text(json.dumps(salida, indent=2, ensure_ascii=False), encoding="utf-8")
    return str(p)


def config_para(cfg: Dict, rfc: str) -> Dict:
    """General + lo específico del RFC (lo del RFC gana si no está vacío)."""
    final = dict(cfg.get("general", {}))
    for k, v in (cfg.get("por_rfc", {}).get((rfc or "").upper(), {}) or {}).items():
        if v not in ("", None):
            final[k] = v
    return final


def dueno_de(detalle: Dict, tipo: str):
    """(rfc, nombre) del contribuyente desde cuya perspectiva se lee el CFDI."""
    if tipo == "Emitido":
        return detalle.get("emisor_rfc", ""), detalle.get("emisor_nombre", "")
    return detalle.get("receptor_rfc", ""), detalle.get("receptor_nombre", "")


def _money(v) -> str:
    try:
        return f"$ {float(v):,.2f}"
    except (TypeError, ValueError):
        return "$ 0.00"


def _hex_valido(c: str, defecto: str = "#1F4E78") -> str:
    return c if isinstance(c, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", c) else defecto


# ---------------------------------------------------------------- PDF individual
def cfdi_a_pdf(detalle: Dict, destino: str, config: Optional[Dict] = None,
               clase: str = "", tipo: str = "", inteligencia: Optional[Dict] = None) -> str:
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import (Image, Paragraph, SimpleDocTemplate, Spacer,
                                        Table, TableStyle)
    except ImportError as e:
        raise RuntimeError(
            "Falta la librería 'reportlab' para generar PDF. Instálala con:\n\n"
            "    pip install reportlab\n\n"
            "(o: pip install -r requirements.txt)"
        ) from e

    d = Path(destino)
    d.parent.mkdir(parents=True, exist_ok=True)

    if config is None:
        config = cargar_config_pdf()
    rfc_dueno, nombre_dueno = dueno_de(detalle, tipo)
    conf = config_para(config, rfc_dueno) if "general" in config else dict(config)

    PRIMARIO = colors.HexColor(_hex_valido(conf.get("color_primario", "")))
    GRIS = colors.HexColor("#5A6577")
    GRIS_CLARO = colors.HexColor("#EEF1F6")

    doc = SimpleDocTemplate(str(d), pagesize=letter,
                            topMargin=14 * mm, bottomMargin=18 * mm,
                            leftMargin=16 * mm, rightMargin=16 * mm,
                            title=f"CFDI {detalle.get('uuid','')}",
                            author=conf.get("titulo") or nombre_dueno or "")
    est_empresa = ParagraphStyle("emp", fontName="Helvetica-Bold", fontSize=13,
                                 textColor=PRIMARIO, leading=16)
    est_titulo = ParagraphStyle("t", fontName="Helvetica-Bold", fontSize=12,
                                textColor=colors.HexColor("#1C2430"), spaceAfter=1)
    est_sub = ParagraphStyle("s", fontName="Helvetica", fontSize=8, textColor=GRIS, leading=10)
    est_lbl = ParagraphStyle("l", fontName="Helvetica-Bold", fontSize=7.5, textColor=GRIS)
    est_val = ParagraphStyle("v", fontName="Helvetica", fontSize=9, leading=11)
    est_val_b = ParagraphStyle("vb", fontName="Helvetica-Bold", fontSize=9, leading=11)
    est_mini = ParagraphStyle("m", fontName="Helvetica", fontSize=6.5, textColor=GRIS,
                              wordWrap="CJK", leading=8)
    est_letra = ParagraphStyle("letra", fontName="Helvetica-Bold", fontSize=38,
                               textColor=colors.white, alignment=1, leading=40)
    est_letra_lbl = ParagraphStyle("letral", fontName="Helvetica-Bold", fontSize=7.5,
                                   textColor=colors.white, alignment=1, leading=9)

    el = []

    # ---------- encabezado: logo | empresa | LETRA
    logo_cell = ""
    logo = conf.get("logo") or ""
    if logo and Path(logo).exists():
        try:
            from reportlab.lib.utils import ImageReader
            iw, ih = ImageReader(logo).getSize()
            alto = 18 * mm
            ancho = min(45 * mm, alto * iw / max(ih, 1))
            logo_cell = Image(logo, width=ancho, height=ancho * ih / max(iw, 1))
        except Exception:  # noqa: BLE001 — un logo roto no debe impedir el PDF
            logo_cell = ""

    titulo_emp = conf.get("titulo") or nombre_dueno or detalle.get("receptor_nombre", "")
    bloque_emp = [Paragraph(titulo_emp or "&nbsp;", est_empresa)]
    if rfc_dueno:
        bloque_emp.append(Paragraph(f"RFC {rfc_dueno}", est_sub))
    if conf.get("subtitulo"):
        bloque_emp.append(Paragraph(conf["subtitulo"], est_sub))

    letra_cell = ""
    if conf.get("mostrar_letra_clase", True) and clase in CLASES:
        nombre_clase, color_clase = CLASES[clase]
        letra_cell = Table([[Paragraph(clase, est_letra)],
                            [Paragraph(nombre_clase.upper(), est_letra_lbl)]],
                           colWidths=[30 * mm], rowHeights=[16 * mm, 6 * mm])
        letra_cell.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(color_clase)),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 1), ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ]))

    ancho_logo = 48 * mm if logo_cell else 1 * mm
    enc = Table([[logo_cell, bloque_emp, letra_cell]],
                colWidths=[ancho_logo, (184 - 32) * mm - ancho_logo, 32 * mm])
    enc.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("LINEBELOW", (0, 0), (-1, 0), 1.2, PRIMARIO),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    el.append(enc)
    el.append(Spacer(1, 8))

    # ---------- título del comprobante
    tipo_desc = detalle.get("tipo_comprobante_desc", "")
    folio = " ".join(x for x in [detalle.get("serie", ""), detalle.get("folio", "")] if x)
    el.append(Paragraph(f"Comprobante de {tipo_desc}", est_titulo))
    el.append(Paragraph(f"CFDI {detalle.get('version','4.0')} &nbsp;·&nbsp; "
                        f"{folio or 's/folio'} &nbsp;·&nbsp; {detalle.get('fecha','')}", est_sub))
    el.append(Spacer(1, 8))

    # ---------- emisor / receptor
    def bloque(titulo, rfc, nombre, extra):
        p = [Paragraph(titulo, est_lbl), Paragraph(nombre or "—", est_val_b),
             Paragraph(f"RFC: {rfc or '—'}", est_val)]
        if extra:
            p.append(Paragraph(extra, est_sub))
        return p

    ce = bloque("EMISOR", detalle.get("emisor_rfc"), detalle.get("emisor_nombre"),
                f"Régimen: {detalle.get('emisor_regimen','')}")
    cr = bloque("RECEPTOR", detalle.get("receptor_rfc"), detalle.get("receptor_nombre"),
                f"Uso CFDI: {detalle.get('uso_cfdi','')}")
    t_er = Table([[ce, cr]], colWidths=[92 * mm, 92 * mm])
    t_er.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOX", (0, 0), (-1, -1), 0.5, GRIS_CLARO),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, GRIS_CLARO),
        ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    el.append(t_er)
    el.append(Spacer(1, 8))

    # ---------- datos de pago del comprobante
    pago = [
        ["Método pago", detalle.get("metodo_pago", "") or "—", "Forma pago", detalle.get("forma_pago", "") or "—"],
        ["Moneda", detalle.get("moneda", ""), "Tipo cambio", str(detalle.get("tipo_cambio", "1"))],
    ]
    t_pago = Table(pago, colWidths=[28 * mm, 64 * mm, 28 * mm, 64 * mm])
    t_pago.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"), ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("TEXTCOLOR", (0, 0), (0, -1), GRIS), ("TEXTCOLOR", (2, 0), (2, -1), GRIS),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    el.append(t_pago)
    el.append(Spacer(1, 8))

    # ---------- conceptos
    filas = [["Cant.", "Unidad", "Descripción", "V. unitario", "Importe"]]
    for c in detalle.get("conceptos", []):
        filas.append([f"{c['cantidad']:g}", c.get("clave_unidad", "") or c.get("unidad", ""),
                      Paragraph(c.get("descripcion", ""), est_val),
                      _money(c["valor_unitario"]), _money(c["importe"])])
    t_con = Table(filas, colWidths=[14 * mm, 18 * mm, 100 * mm, 26 * mm, 26 * mm], repeatRows=1)
    t_con.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), PRIMARIO), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ALIGN", (0, 0), (0, -1), "CENTER"), ("ALIGN", (3, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, GRIS_CLARO]),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ]))
    el.append(t_con)
    el.append(Spacer(1, 8))

    # ---------- totales
    tot = [["SubTotal", _money(detalle.get("subtotal"))]]
    if detalle.get("descuento"):
        tot.append(["Descuento", "- " + _money(detalle.get("descuento"))])
    if detalle.get("iva_trasladado"):
        tot.append(["IVA trasladado", _money(detalle.get("iva_trasladado"))])
    if detalle.get("ieps_trasladado"):
        tot.append(["IEPS trasladado", _money(detalle.get("ieps_trasladado"))])
    if detalle.get("iva_retenido"):
        tot.append(["IVA retenido", "- " + _money(detalle.get("iva_retenido"))])
    if detalle.get("isr_retenido"):
        tot.append(["ISR retenido", "- " + _money(detalle.get("isr_retenido"))])
    tot.append(["TOTAL", _money(detalle.get("total"))])
    t_tot = Table(tot, colWidths=[40 * mm, 40 * mm], hAlign="RIGHT")
    t_tot.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9), ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("TEXTCOLOR", (0, 0), (0, -2), GRIS),
        ("LINEABOVE", (0, -1), (-1, -1), 1, PRIMARIO),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"), ("FONTSIZE", (0, -1), (-1, -1), 11),
        ("TEXTCOLOR", (0, -1), (-1, -1), PRIMARIO),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    el.append(t_tot)
    el.append(Spacer(1, 12))

    # ---------- complemento de pago
    if detalle.get("es_pago") or detalle.get("pago_monto"):
        el.append(Paragraph("COMPLEMENTO DE PAGO", est_lbl))
        el.append(Paragraph(f"Monto pagado: {_money(detalle.get('pago_monto'))} &nbsp;·&nbsp; "
                            f"Fecha: {detalle.get('pago_fecha','')} &nbsp;·&nbsp; "
                            f"Forma: {detalle.get('pago_forma','')}", est_val_b))
        extra = []
        if detalle.get("pago_iva"):
            extra.append(f"IVA del pago: {_money(detalle.get('pago_iva'))}")
        if detalle.get("pago_num_operacion"):
            extra.append(f"Núm. operación: {detalle.get('pago_num_operacion')}")
        if extra:
            el.append(Paragraph(" &nbsp;·&nbsp; ".join(extra), est_sub))
        docs = detalle.get("pago_docs", [])
        if docs:
            fd = [["UUID (factura pagada)", "Serie·Folio", "Parc.", "Base", "Tasa",
                   "IVA", "Pagado", "Saldo ins."]]
            for dd in docs:
                sf = "·".join(x for x in [dd.get("serie", ""), dd.get("folio", "")] if x)
                tasa = f"{float(dd['tasa'])*100:.0f}%" if dd.get("tasa") else ""
                fd.append([Paragraph(dd["uuid"], est_mini), sf, dd.get("parcialidad", ""),
                           _money(dd.get("base", 0)), tasa, _money(dd.get("iva", 0)),
                           _money(dd["pagado"]), _money(dd["saldo_insoluto"])])
            t_d = Table(fd, colWidths=[40 * mm, 17 * mm, 9 * mm, 22 * mm, 10 * mm,
                                       21 * mm, 22 * mm, 22 * mm], repeatRows=1)
            t_d.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), GRIS), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 7),
                ("ALIGN", (3, 0), (-1, -1), "RIGHT"), ("ALIGN", (2, 0), (2, -1), "CENTER"),
                ("ALIGN", (4, 0), (4, -1), "CENTER"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, GRIS_CLARO]),
                ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ]))
            el.append(Spacer(1, 4))
            el.append(t_d)
        el.append(Spacer(1, 10))

    # ---------- relacionados
    rels = detalle.get("relacionados", [])
    if rels:
        el.append(Paragraph("CFDI RELACIONADOS", est_lbl))
        for r in rels:
            el.append(Paragraph(f"{r['uuid']} &nbsp;—&nbsp; {r.get('tipo_desc','')}", est_val))
        el.append(Spacer(1, 10))

    # ---------- inteligencia (estatus de pago calculado con lo leído)
    if inteligencia and conf.get("mostrar_inteligencia", True) and inteligencia.get("estatus"):
        el.append(Paragraph("SEGUIMIENTO DE PAGO (calculado con los XML leídos)", est_lbl))
        filas_i = [["Estatus", inteligencia.get("estatus", "")],
                   ["Pagado con REP", _money(inteligencia.get("pagado_rep", 0))],
                   ["Notas de crédito aplicadas", _money(inteligencia.get("nc_aplicadas", 0))],
                   ["Saldo pendiente", _money(inteligencia.get("saldo_pendiente", 0))]]
        t_i = Table(filas_i, colWidths=[50 * mm, 40 * mm], hAlign="LEFT")
        t_i.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 8.5), ("TEXTCOLOR", (0, 0), (0, -1), GRIS),
            ("FONTNAME", (1, 0), (1, 0), "Helvetica-Bold"), ("ALIGN", (1, 1), (1, -1), "RIGHT"),
            ("LINEBELOW", (0, -1), (-1, -1), 0.5, GRIS_CLARO),
            ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        el.append(t_i)
        pagos = inteligencia.get("pagos", [])
        if pagos:
            fp = [["REP (UUID)", "Fecha pago", "Parc.", "Pagado", "Saldo insoluto"]]
            for e in pagos:
                fp.append([Paragraph(e.get("rep_uuid", ""), est_mini), e.get("fecha_pago", "")[:10],
                           e.get("parcialidad", ""), _money(e.get("imp_pagado")),
                           _money(e.get("saldo_insoluto"))])
            t_p = Table(fp, colWidths=[62 * mm, 26 * mm, 12 * mm, 30 * mm, 30 * mm], hAlign="LEFT")
            t_p.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), GRIS_CLARO), ("FONTSIZE", (0, 0), (-1, -1), 7),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("ALIGN", (3, 0), (-1, -1), "RIGHT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]))
            el.append(Spacer(1, 4))
            el.append(t_p)
        el.append(Spacer(1, 10))

    # ---------- timbre
    el.append(Paragraph("TIMBRE FISCAL", est_lbl))
    el.append(Paragraph(f"UUID: {detalle.get('uuid','')}", est_val))
    el.append(Paragraph(f"Fecha timbrado: {detalle.get('fecha_timbrado','')}", est_sub))
    if conf.get("mostrar_sello_sat") and detalle.get("sello_sat"):
        el.append(Spacer(1, 4))
        el.append(Paragraph("Sello SAT:", est_lbl))
        el.append(Paragraph(detalle["sello_sat"], est_mini))
    el.append(Spacer(1, 8))
    el.append(Paragraph("Representación impresa de un CFDI. Documento informativo, "
                        "no sustituye al XML timbrado.", est_sub))

    pie = conf.get("pie", "")

    def _pie(canvas, documento):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(GRIS)
        if pie:
            canvas.drawString(16 * mm, 9 * mm, str(pie)[:140])
        canvas.drawRightString(letter[0] - 16 * mm, 9 * mm, f"Página {documento.page}")
        canvas.restoreState()

    doc.build(el, onFirstPage=_pie, onLaterPages=_pie)
    return str(d)


# ---------------------------------------------------------------- generación masiva
_INVALIDOS = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')


def nombre_pdf(plantilla: str, datos: Dict) -> str:
    """Nombre de archivo seguro para Windows a partir de la plantilla."""
    fecha = (datos.get("Fecha") or "")[:10].replace("-", "")
    tipo = datos.get("Tipo", "")
    contraparte = datos.get("RFC Receptor") if tipo == "Emitido" else datos.get("RFC Emisor")
    uuid = (datos.get("UUID") or "SINUUID").upper()
    valores = {"fecha": fecha or "SINFECHA", "clase": datos.get("Clase") or "X", "tipo": tipo,
               "rfc_contraparte": contraparte or "", "serie": datos.get("Serie", ""),
               "folio": datos.get("Folio", ""), "uuid8": uuid[:8], "uuid": uuid}
    try:
        nombre = plantilla.format(**valores)
    except (KeyError, IndexError, ValueError):
        nombre = CONFIG_DEFAULT["general"]["nombre_archivo"].format(**valores)
    nombre = _INVALIDOS.sub("", nombre).strip(" ._") or uuid
    nombre = re.sub(r"_{2,}", "_", nombre)
    return nombre[:150] + ".pdf"


def generar_pdfs(filas: List, carpeta: str, config: Optional[Dict] = None,
                 inteligencia_de: Optional[Callable] = None,
                 progreso: Optional[Callable] = None,
                 cancelado: Callable[[], bool] = lambda: False,
                 sobrescribir: bool = False) -> Dict:
    """Genera un PDF por CFDI (no por fila: un REP con 3 facturas = 1 PDF).
    filas: renglones de la tabla (Renglon o dict). Devuelve un resumen."""
    from .lector import leer_detalle

    if config is None:
        config = cargar_config_pdf()
    destino = Path(carpeta)
    destino.mkdir(parents=True, exist_ok=True)
    plantilla = config.get("general", {}).get("nombre_archivo") or \
        CONFIG_DEFAULT["general"]["nombre_archivo"]

    unicos, vistos = [], set()
    for f in filas:
        d = f.datos if hasattr(f, "datos") else f
        k = ((d.get("UUID") or d.get("Archivo") or "").upper(), d.get("Tipo", ""))
        if k in vistos:
            continue
        vistos.add(k)
        unicos.append(d)

    res = {"generados": 0, "omitidos": 0, "errores": [], "carpeta": str(destino),
           "total": len(unicos), "cancelado": False}
    for i, d in enumerate(unicos, 1):
        if cancelado():
            res["cancelado"] = True
            break
        salida = destino / nombre_pdf(plantilla, d)
        try:
            if salida.exists() and not sobrescribir:
                res["omitidos"] += 1
            else:
                det = leer_detalle(d.get("Archivo", ""))
                if not det:
                    raise ValueError("no es un CFDI legible")
                intel = inteligencia_de(d) if inteligencia_de else None
                cfdi_a_pdf(det, str(salida), config=config, clase=d.get("Clase", ""),
                           tipo=d.get("Tipo", ""), inteligencia=intel)
                res["generados"] += 1
        except Exception as e:  # noqa: BLE001 — un XML malo no detiene el lote
            res["errores"].append((d.get("Archivo", ""), str(e)))
        if progreso:
            progreso(i, len(unicos))
    return res
